function AboutPost() {
    return (
      <div style={{ padding: 20 }}>
    
              <h2>This is inner section of About</h2>
              
      </div>
    );
  }


export default AboutPost;
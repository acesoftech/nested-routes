const BlogPosts = {
    '1': {
      title: 'First Blog Post',
      description: 'Lorem ipsum dolor sit amet, consectetur adip.'
    },
    '2': {
      title: 'Second Blog Post',
      description: 'Hello React Router v6<img src="">'
    },

    '3': {
      title: 'Third Blog Post',
      description: 'Hello React Router v7'
    }

  };
  
  export default BlogPosts;
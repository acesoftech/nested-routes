import React from 'react';
import './App.css';
import BlogPosts from './BlogPosts';
import Home from './Home';
import About from './About';
import AboutPost from './AboutPost';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  Outlet,
  useParams
} from 'react-router-dom';

import {useState,useEffect} from 'react';


function App() {
  return (
    <Router>
      <nav style={{ margin: 10 }}>
        <Link to="/" style={{ padding: 5 }}>
          Home
        </Link>
        <Link to="/about" style={{ padding: 5 }}>
          About
        </Link>
        <Link to="/posts/" style={{ padding: 5 }}>
          Posts
        </Link>
      </nav>
      {/* Rest of the code remains same */}
      <Routes>
        <Route path="/" element={<Home />} />

        <Route path="/about" element={<About />} >
           <Route path="/about" element={<AboutPost />} />
            <Route path="/about:id" element={<AboutPost />} />
        </Route>

        <Route path="/posts" element={<Posts />}>
          <Route path="/posts" element={<PostLists />} />
          <Route path="/posts:id" element={<Post />} />
        </Route>
      </Routes>
    </Router>
  );
}


function Posts() { // Container here Blog list will load
  return (
    <div style={{ padding: 20,backgroundColor:'yellow' }}>
      <h2>Blog</h2>
      render any matching child 
      <Outlet />
      
    </div>
  );
}

function PostLists() { // List of the blog
  // return (
  //   <ul>
  //     {Object.entries(BlogPosts).map(([slug, { title }]) => (
  //       <li key={slug}>
  //         <Link to={`/posts/${slug}`}>
  //           <h3>{title}</h3>
  //         </Link>
  //       </li>
  //     ))}
  //   </ul>
  // );



const [posts, setPosts] = useState([]);

  useEffect(() => {
    // Define the API endpoint
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts';

    // Fetch data from the API
    fetch(apiUrl)
      .then(response => response.json())
      .then(resultData => setPosts(resultData))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <div>
      <h1>API Data Display</h1>
      {posts.length ? (
        <div>
          {posts.map(post => (
            <div key={post.id}>
              <p><Link to={`/post/${post.id}`}>Title: {post.title}</Link></p>
              <p>Body: {post.body}</p>
              <hr />
            </div>
          ))}
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );


}

function Post() { // Individual Blog
  // const { slug } = useParams();

  // ///console.log(slug);
  // const post = BlogPosts[slug];

  // const { title, description } = post;

  // return (
  //   <div style={{ padding: 20, backgroundColor:'green' }}>
  //     <h3>{title}</h3>
  //     <p>{description}</p>
  //   </div>
  // );



  const [data, setData] = useState(null);
  const {id} = useParams();
  useEffect(() => {
    // Define the API endpoint
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts/'+id;

    // Fetch data from the API
    fetch(apiUrl)
      .then(response => response.json())
      .then(resultData => setData(resultData))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  console.log(data);

  return (
    <div>
      <h1>API Data Display</h1>
      {data ? (
        <div>
          <p>Title: {data.title}</p>
          <p>Body: {data.body}</p>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );

}


export default App;
